import os
import pandas as pd

# A mock list of messy filenames to practice on
messy_files = [
    "the_hobbit_by_j_r_r_tolkien.epub",
    "GREAT GATSBY.pdf",
    "To_kill_a_mockingbird-v2.mobi",
    "1984_george_orwell.PDF"
]

# Create an empty list to hold our structured dictionary records
book_data = []

for filename in messy_files:
    # 1. Separate the name and the extension
    name, extension = os.path.splitext(filename)

    # 2. Clean the title: replace underscores/hyphens, strip spaces, Title Case
    clean_title = name.replace("_", " ").replace("-", " ").strip().title()

    # 3. Standardize the extension (force lowercase)
    clean_ext = extension.lower()

    # 4. Store the data as a dictionary record
    book_data.append({
        "Original Filename": filename,
        "Cleaned Title": clean_title,
        "Extension": clean_ext
    })

# Convert the list of dictionaries into a Pandas DataFrame
df = pd.DataFrame(book_data)

# Print the DataFrame
print(df)